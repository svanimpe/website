/* Exercises 7.1 to 7.3 */

import Foundation

struct Vector {
        
    var x: Double
    var y: Double
    
    var length: Double {
        sqrt(x * x + y * y)
    }
    
    mutating func add(_ other: Vector) {
        x += other.x
        y += other.y
    }
    
    func adding(_ other: Vector) -> Vector {
        Vector(x: x + other.x, y: y + other.y)
    }
    
    mutating func subtract(_ other: Vector) {
        x -= other.x
        y -= other.y
    }
    
    func subtracting(_ other: Vector) -> Vector {
        Vector(x: x - other.x, y: y - other.y)
    }
    
    func distance(to other: Vector) -> Double {
        subtracting(other).length
    }
}

/* Exercises 7.4 to 7.6 */

struct Rectangle {
    
    var corner1: Vector
    var corner2: Vector
    
    init(x: Double, y: Double, width: Double, height: Double) {
        corner1 = Vector(x: x, y: y)
        corner2 = Vector(x: x + width, y: y + height)
    }
    
    init?(corner1: Vector, corner2: Vector) {
        if corner1.x == corner2.x || corner1.y == corner2.y {
            return nil
        }
        self.corner1 = corner1
        self.corner2 = corner2
    }
    
    var width: Double {
        abs(corner2.x - corner1.x)
    }
    
    var heigth: Double {
        abs(corner2.y - corner1.y)
    }
    
    var area: Double {
        width * heigth
    }
}

/* Exercises 7.7 to 7.8 */

struct Circle {
    
    static var unit = Circle(center: Vector(x: 0, y: 0), radius: 1)
    
    var center: Vector
    var radius: Double
    
    var diameter: Double {
        get {
            2 * radius
        }
        set {
            radius = newValue / 2
        }
    }
    
    var circumference: Double {
        get {
            2 * .pi * radius
        }
        set {
            radius = newValue / (2 * .pi)
        }
    }
    
    var area: Double {
        get {
            radius * radius * .pi
        }
        set {
            radius = sqrt(newValue / .pi)
        }
    }
}
