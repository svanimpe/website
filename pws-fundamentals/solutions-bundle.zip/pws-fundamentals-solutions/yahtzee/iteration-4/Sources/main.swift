let numberOfPlayers = Input.askNumberOfPlayers()
let game = Game(numberOfPlayers: numberOfPlayers)
game.play()
