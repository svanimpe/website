/// A player.
class Player {

    /// The player's name, which must be unique.
    let name: String

    /// The player's score card.
    let card: ScoreCard

    /// Initializes a player with the given name and an empty score card.
    init(name: String) {
        self.name = name
        card = ScoreCard()
    }
}

extension Player: Hashable {

    /// Compares two players using their name.
    static func ==(lhs: Player, rhs: Player) -> Bool {
        lhs.name == rhs.name
    }

    /// Computes a player's hash code using their name.
    func hash(into hasher: inout Hasher) {
        hasher.combine(name)
    }
}
