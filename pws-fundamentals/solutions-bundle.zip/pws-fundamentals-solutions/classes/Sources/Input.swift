enum Input {

    static func one(of actions: [Action]) -> Action {
        while true {  // Loop until the user inputs one of the actions.
            let input = readLine()!.lowercased()
            if let action = Action(from: input), actions.contains(action) {
                return action
            }
        }
    }

    static func playerConfirms() -> Bool {
        let answer = one(of: [.yes, .no])
        return answer == .yes
    }
}
