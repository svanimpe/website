let initialCredits = 500
let player = Player(credits: initialCredits)
print("""
      Welcome to Blackjack!
      A bet is \(Game.bet) credits.

      """)
while player.credits >= Game.bet {
    print("""
          You have \(player.credits) credits.
          Would you like to play a hand?
          """)
    if !Input.playerConfirms() {
        break
    }
    player.credits -= Game.bet
    let game = Game(player: player)
    game.play()
    print("")
}
print("You've ended the game with \(player.credits) credits.")
if player.credits > initialCredits {
    print("That's \(player.credits - initialCredits) credits won!")
} else if player.credits < initialCredits {
    print("You've lost \(initialCredits - player.credits) credits.")
}
