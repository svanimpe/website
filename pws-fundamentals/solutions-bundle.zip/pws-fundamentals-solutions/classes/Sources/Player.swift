class Player {

    var credits: Int

    private(set) var hands: [Hand]
    private var currentHandIndex: Int
    private var isFirstHand: Bool
    
    var hasInsurance: Bool
    
    init(credits: Int) {
        self.credits = credits
        hands = [Hand(), Hand(), Hand(), Hand()]
        currentHandIndex = 0
        isFirstHand = true
        hasInsurance = false
    }

    var hasMultipleHands: Bool {
        hands.filter { !$0.isEmpty }.count > 1
    }

    var hasBlackjack: Bool {
        hands[0].isBlackjack && !hasMultipleHands
    }

    var canSplitHand: Bool {
        let nextHand = hands.first { $0.isEmpty }
        return hands[currentHandIndex].isSplittable && nextHand != nil
    }

    var allHandsBusted: Bool {
        hands.allSatisfy { $0.isEmpty || $0.isBusted }
    }

    func resetHands() {
        hands = [Hand(), Hand(), Hand(), Hand()]
        currentHandIndex = 0
        isFirstHand = true
        hasInsurance = false
    }

    func nextHand() -> (index: Int, hand: Hand)? {
        if isFirstHand {
            isFirstHand = false
        } else if currentHandIndex == hands.count - 1 || hands[currentHandIndex + 1].isEmpty {
            return nil
        } else {
            currentHandIndex += 1
        }
        return (currentHandIndex, hands[currentHandIndex])
    }

    func draw(from deck: Deck) {
        let card = deck.draw()
        hands[currentHandIndex].receive(card)
    }

    func splitHand() {
        if !canSplitHand {
            return
        }
        let nextHand = hands.firstIndex { $0.isEmpty }!
        let card = hands[currentHandIndex].split()
        hands[nextHand].receive(card)
    }
}
