class Game {

    static let bet = 50

    private let player: Player
    private let deck: Deck
    private let dealer: Hand

    init(player: Player) {
        self.player = player
        player.resetHands()
        deck = Deck(size: 4)
        dealer = Hand()
    }

    func play() {
        dealFirstHand()
        askForInsurance()
        if dealerHasBlackjack() {
            return
        }
        if playerHasBlackjack() {
            return
        }
        while let (index, hand) = player.nextHand() {  // for all hands
            if index > 0 {
                print("Continuing with hand \(index + 1).")
                // Add a second card as this hand is the result of a split and has only one card.
                player.draw(from: deck)
                print("You have \(hand.description(allowBlackjack: false)).")
                // Split aces draw only one card.
                if hand.isShowingAce {
                    continue  // with the next hand
                }
            }
            var firstAction = true
            while hand.value < 21 {
                let action: Action
                if firstAction && player.credits >= Game.bet && player.canSplitHand {
                    print("Would you like to \(Action.hit.description), \(Action.stand.description), \(Action.split.description) or \(Action.double.description)?")
                    action = Input.one(of: [.hit, .stand, .split, .double])
                } else if firstAction && player.credits >= Game.bet {
                    print("Would you like to \(Action.hit.description), \(Action.stand.description) or \(Action.double.description)?")
                    action = Input.one(of: [.hit, .stand, .double])
                } else {
                    print("Would you like to \(Action.hit.description) or \(Action.stand.description)?")
                    action = Input.one(of: [.hit, .stand])
                }
                firstAction = false
                if action == .stand {
                    break  // no more actions for this hand
                }
                if action == .split {
                    player.credits -= Game.bet
                    player.splitHand()
                    if hand.isShowingAce {
                        print("Splitting aces. Each hand will draw only one additional card.")
                        player.draw(from: deck)
                        print("You have \(hand.description(allowBlackjack: false)).")
                        break  // no more actions for this hand
                    } else {
                        print("Hand split. Continuing with the current hand.")
                        // Allow resplitting and doubling down after a split.
                        firstAction = true
                    }
                }
                // If the player hit, doubled down or split cards other than aces, draw an additional card.
                player.draw(from: deck)
                print("You have \(hand.description(allowBlackjack: false)).")
                if hand.isBusted {
                    print("Busted.")
                }
                if action == .double {
                    player.credits -= Game.bet
                    hand.isDoubledDown = true
                    break  // no more actions for this hand
                }
            }
        }
        if player.allHandsBusted {
            print("You lose.")
            // Skip the dealer and payout phase.
            return
        }
        doDealerTurn()
        payOut()
    }

    private func dealFirstHand() {
        player.draw(from: deck)
        player.draw(from: deck)
        print("You have \(player.hands[0].description()).")
        dealer.receive(deck.draw())
        dealer.receive(deck.draw())
        // Only show the dealer's first card.
        print("Dealer has \(dealer.cards[0].description).")
    }

    private func askForInsurance() {
        if dealer.isShowingAce && player.credits >= Game.bet / 2 {
            print("Would you like to buy insurance?")
            if Input.playerConfirms() {
                player.credits -= Game.bet / 2
                player.hasInsurance = true
            }
        }
    }

    private func dealerHasBlackjack() -> Bool {
        if !dealer.isBlackjack {
            return false
        }
        print("Dealer has \(dealer.description()).")
        if player.hasInsurance {
            player.credits += 3 * Game.bet / 2
        }
        if player.hasBlackjack {
            print("it's a tie.")
            player.credits += Game.bet
        } else {
            print("You lose.")
        }
        return true
    }

    private func playerHasBlackjack() -> Bool {
        if !player.hasBlackjack {
            return false
        }
        print("You win.")
        player.credits += 5 * Game.bet / 2
        return true
    }

    private func doDealerTurn() {
        print("Dealer reveals \(dealer.cards[1].description).")
        while dealer.value < 17 || dealer.value == 17 && dealer.isSoft {
            let card = deck.draw()
            dealer.receive(card)
            print("Dealer draws \(card.description).")
        }
        print("Dealer has \(dealer.description()).")
        if dealer.isBusted {
            print("Dealer busts.")
        }
    }

    private func payOut() {
        for (index, hand) in player.hands.enumerated() where !hand.isEmpty && !hand.isBusted {
            if dealer.isBusted || hand.value > dealer.value {
                print(player.hasMultipleHands ? "You win hand \(index + 1)." : "You win.")
                player.credits += hand.isDoubledDown ? 4 * Game.bet : 2 * Game.bet
            } else if hand.value < dealer.value {
                print(player.hasMultipleHands ? "You lose hand \(index + 1)." : "You lose.")
            } else {
                print(player.hasMultipleHands ? "Hand \(index + 1) ties." : "it's a tie.")
                player.credits += hand.isDoubledDown ? 2 * Game.bet : Game.bet
            }
        }
    }
}
