enum Suit: String {

    case hearts = "♥"
    case diamonds = "♦"
    case spades = "♠"
    case clubs = "♣"
}

enum Rank: String {

    case ace = "A"
    case two = "2"
    case three = "3"
    case four = "4"
    case five = "5"
    case six = "6"
    case seven = "7"
    case eight = "8"
    case nine = "9"
    case ten = "10"
    case jack = "J"
    case queen = "Q"
    case king = "K"

    var value: Int {
        switch self {
        case .ace: 11
        case .two: 2
        case .three: 3
        case .four: 4
        case .five: 5
        case .six: 6
        case .seven: 7
        case .eight: 8
        case .nine: 9
        case .ten, .jack, .queen, .king: 10
        }
    }
}

struct Card {

    let rank: Rank
    let suit: Suit

    var value: Int {
        rank.value
    }

    var description: String {
        "\(rank.rawValue)\(suit.rawValue)"
    }
}
