class Deck {

    private var cards: [Card]
    private let size: Int

    init(size: Int) {
        self.size = size
        cards = []
        // Initializers cannot call methods before all properties are initialized.
        // That's why you have to assign a value to `cards` before you call `initialize`.
        initialize()
    }

    private func initialize() {
        cards = []
        for suit in [Suit.hearts, .diamonds, .spades, .clubs] {
            for rank in [Rank.ace, .two, .three, .four, .five, .six, .seven, .eight, .nine, .ten, .jack, .queen, .king] {
                for _ in 1...size {
                    cards.append(Card(rank: rank, suit: suit))
                }
            }
        }
        cards.shuffle()
    }

    func draw() -> Card {
        if cards.isEmpty {
            initialize()
        }
        return cards.removeLast()
    }
}
