class Hand {

    private(set) var cards: [Card] = []
    var isDoubledDown = false

    var isEmpty: Bool {
        cards.isEmpty
    }

    var value: Int {
        var total = cards.reduce(0) {
            $0 + $1.value
        }
        var numberOfSoftAces = cards.filter { $0.rank == .ace }.count
        while total > 21 && numberOfSoftAces > 0 {
            numberOfSoftAces -= 1
            total -= 10
        }
        return total
    }

    var isSoft: Bool {
        var total = cards.reduce(0) {
            $0 + $1.value
        }
        var numberOfSoftAces = cards.filter { $0.rank == .ace }.count
        while total > 21 && numberOfSoftAces > 0 {
            numberOfSoftAces -= 1
            total -= 10
        }
        return numberOfSoftAces > 0
    }

    var isSplittable: Bool {
        cards.count == 2 && cards[0].value == cards[1].value
    }

    var isShowingAce: Bool {
        !cards.isEmpty && cards.first!.rank == .ace
    }

    var isBlackjack: Bool {
        cards.count == 2 && value == 21
    }

    var isBusted: Bool {
        value > 21
    }

    func receive(_ card: Card) {
        cards.append(card)
    }

    func split() -> Card {
        cards.removeLast()
    }

    func description(allowBlackjack: Bool = true) -> String {
        let listOfCards = cards.map { $0.description }.joined(separator: ", ")
        if allowBlackjack && isBlackjack {
            return "blackjack: \(listOfCards)"
        }
        return "\(isSoft ? "soft " : "")\(value): \(listOfCards)"
    }
}
