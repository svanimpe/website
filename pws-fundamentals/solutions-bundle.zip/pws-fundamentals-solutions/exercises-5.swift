/* Exercise 5.1 */

func sum(of numbers: [Double]) -> Double {
    var sum = 0.0
    for number in numbers {
        sum += number
    }
    return sum
}
sum(of: [5, 3, 2, 1, 4])

/* Exercise 5.2 */

func reversed(_ numbers: [Double]) -> [Double] {
    var result: [Double] = []
    // Iterate over the original array backwards
    var index = numbers.count - 1
    while index >= 0 {
        // and build a new array as you go.
        result.append(numbers[index])
        index -= 1
    }
    return result
}
reversed([3, 2, 1])

// Alternative solution:

func reversed2(_ numbers: [Double]) -> [Double] {
    var result: [Double] = []
    // Iterate over the original array
    for number in numbers {
        // and build a new array backwards by inserting elements at the front.
        result.insert(number, at: 0)  // Not efficient!
    }
    return result
}
reversed2([3, 2, 1])

/* Exercise 5.3 */

func sorted(_ numbers: [Double]) -> [Double] {
    var result: [Double] = []
    for number in numbers {
        // Compare each number to the ones you've already sorted
        var index = 0
        while index < result.count {
            // and if it's smaller than an already sorted number,
            if number < result[index] {
                // insert it before that number.
                result.insert(number, at: index)
                break
            }
            index += 1
        }
        // Otherwise, it's the largest number, so append it at the end.
        if index == result.count {
            result.append(number)
        }
    }
    return result
}
sorted([5, 3, 2, 1, 4])

/* Exercise 5.4 */

func characters(in text: String) -> [Character: Int] {
    var counts: [Character: Int] = [:]
    for character in text {
        counts[character, default: 0] += 1
    }
    return counts
}
characters(in: "Hello, world!")

/* Exercise 5.5 */

func words(in text: String) -> [String: Int] {
    var counts: [String: Int] = [:]
    var currentWord: String? = nil
    for character in text {
        switch character {
        case " ", "\t", "\n", ",", ";", ":", ".", "?", "!":
            // Whitespace or punctuation ends the current word.
            if let currentWord {
                counts[currentWord, default: 0] += 1
            }
            currentWord = nil
        default:
            // Continue the current word or start a new one.
            if currentWord == nil {
                currentWord = String(character)
            } else {
                currentWord!.append(character)
            }
        }
    }
    // Don't forget to count the last word as there may not be whitespace or punctuation after it.
    if let currentWord {
        counts[currentWord, default: 0] += 1
    }
    return counts
}
words(in: "Hello you, how are you?")

/* Exercise 5.6 */

func stats(for text: String) -> (lineCount: Int, wordCount: Int, characterCount: Int) {
    var lineCount = 1
    var wordCount = 0
    var inWord = false
    
    for character in text {
        switch character {
        case " ", "\t", "\n", ",", ";", ":", ".", "?", "!":
            // Whitespace or punctuation ends the current word.
            if inWord {
                wordCount += 1
            }
            inWord = false
            // Check for the end of a line.
            if character == "\n" {
                lineCount += 1
            }
        default:
            inWord = true
        }
    }
    // Don't forget to count the last word as there may not be whitespace or punctuation after it.
    if inWord {
        wordCount += 1
    }
    return (lineCount, wordCount, text.count)
}
stats(for: """
    Lorem ipsum dolor sit amet, consectetur adipiscing elit.
    In tristique dolor tellus, eu sollicitudin tellus porttitor at.
    Fusce gravida sed massa nec luctus. Suspendisse ac nibh sit amet ex aliquam vulputate a non augue.
    Vivamus sollicitudin sed mi quis pretium. Suspendisse aliquet porta tincidunt.
    Suspendisse sagittis massa quis neque elementum vehicula. Morbi id volutpat enim.
    In tempus lobortis quam, nec varius neque viverra vitae. Pellentesque volutpat finibus ultricies.
    In mattis congue semper. Proin tincidunt hendrerit tincidunt. Nunc eu fringilla felis, vitae faucibus diam.
    """)
